<?php
if(!defined('ABSPATH'))exit;
/** The four documents of the former registration page: where each is completed online, with the original PDF. */
function pa_documents_overview($kind){
 $token=function_exists('pa_test_request_token')?pa_test_request_token():'';
 $link=function($route)use($token){$url=pa_link($route);return $token?add_query_arg('pa_test',$token,$url):$url;};
 $docs=[
  ['Customer Application','Customer-Application','Steps 1 and 2 of the online account application: company, billing and references.','application'],
  ['Credit Application','Credit-Application','Step 3 of the online account application, only if you request credit.','application'],
  ['Terms and Agreements','Terms-and-Agreements-Pelham','Step 4 of the online account application: read and sign online.','application'],
  ['Claim Form','Claim-Form','Separate online form to report loss or damage on a shipment.','claim'],
 ];
 $html='<section class="pa-doc-overview" aria-labelledby="pa-doc-overview-title"><h3 id="pa-doc-overview-title">'.esc_html(pa_t('Your four Pelham documents')).'</h3><p>'.esc_html(pa_t($kind==='claim'?'The Claim Form is completed and signed on this page. The Customer Application, Credit Application and Terms and Agreements are part of the online account application.':'The Customer Application, Credit Application and Terms and Agreements are completed and signed in the online application below. The Claim Form has its own page.')).'</p><ul class="pa-doc-grid">';
 foreach($docs as [$title,$file,$where,$flow]){
  $here=$flow===$kind;
  $html.='<li class="pa-doc-card'.($here?' is-here':'').'"><svg class="pa-doc-icon" aria-hidden="true" width="28" height="28" viewBox="0 0 24 24"><path d="M6 2.75h8.5L19.25 7.5v13.75H6zM14.25 3v4.75H19M9 12h7M9 15.5h7M9 19h4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>';
  $html.='<h4>'.esc_html(pa_t($title)).'</h4><p>'.esc_html(pa_t($where)).'</p><div class="pa-doc-actions">';
  $html.=$here?'<span class="pa-doc-here">'.esc_html(pa_t($flow==='claim'?'On this page':'In this application')).'</span>':'<a class="pa-doc-go" href="'.esc_url($link($flow==='claim'?'claims':'register')).'">'.esc_html(pa_t($flow==='claim'?'Open the claim form':'Open the account application')).'</a>';
  $html.='<a class="pa-doc-pdf" href="'.esc_url(plugins_url('documents/'.$file.'.pdf',dirname(__DIR__).'/pelham-applications.php')).'" target="_blank" rel="noopener">'.esc_html(pa_t('View original PDF')).'<span class="screen-reader-text"> '.esc_html(pa_t('(opens in a new tab)')).'</span></a></div></li>';
 }
 return $html.'</ul></section>';
}
function pa_form($kind){
 wp_enqueue_style('pelham-applications',plugins_url('../assets/applications.css',__FILE__),[],PA_VERSION);
 wp_enqueue_script('pelham-applications',plugins_url('../assets/applications.js',__FILE__),[],PA_VERSION,true);
 $schema=pa_schema($kind);$steps=$kind==='claim'?['Shipment','People involved','Incident & evidence','Agreements & signature','Review & send']:['Your company','Billing & references','Credit options','Agreements & signatures','Review & send'];
 $groups=$kind==='claim'?[['shipment'],['parties'],['incident'],['claim_agreement'],[]]:[['company'],['billing','references'],['credit'],['agreements'],[]];
 ob_start(); ?>
<section class="pa-app" data-kind="<?php echo esc_attr($kind); ?>" data-api="<?php echo esc_url(rest_url('pelham-applications/v1/')); ?>">
 <div class="pa-intro"><span class="pa-eyebrow">PELHAM · <?php echo $kind==='claim'?'CLAIMS':'CUSTOMER APPLICATION'; ?></span><h2><?php echo $kind==='claim'?'Tell us what happened.':'Your next move starts here.'; ?></h2><p><?php echo $kind==='claim'?'Complete your claim, attach supporting evidence and sign online.':'Complete your company details, review the agreements and sign online. No printing or scanning of forms required.'; ?></p><div class="pa-benefits"><span>Save & continue later</span><span>Draw or upload signatures</span><span>Reviewed by our team</span></div></div>
 <?php echo pa_documents_overview($kind); ?>
 <?php echo pa_test_controls(); ?>
 <div class="pa-status" role="status" aria-live="polite"></div><div class="pa-errors" role="alert" tabindex="-1" hidden></div>
 <noscript><p><?php echo pa_t('This digital application needs JavaScript to save securely and capture signatures. Please enable it or <a href="'.esc_url(pa_link('contact')).'">contact our team for assistance</a>.'); ?></p></noscript>
 <form class="pa-gate" hidden novalidate><h3>Start with your email</h3><p>We’ll send a private link so you can verify your email and return to your saved request.</p><label>Email address<input type="email" name="email" required autocomplete="email" maxlength="150"></label><label class="pa-honey" aria-hidden="true">Leave empty<input name="website" tabindex="-1" autocomplete="off"></label><button type="submit" class="button">Email me a private link <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path d="M5 19 19 5M6 5h13v13" fill="none" stroke="currentColor" stroke-width="1.7"/></svg></button><p class="pa-help">You can use the same email to resume an unfinished request. This does not create customer portal access.</p></form>
 <div class="pa-workspace" hidden><div class="pa-session"><span class="pa-reference"></span><span class="pa-save-state" aria-live="polite"></span><button type="button" class="pa-signout">Save & sign out</button></div>
 <ol class="pa-steps" aria-label="Application progress"><?php foreach($steps as $i=>$title){?><li><button type="button" data-step="<?php echo $i; ?>"><span><?php echo $i+1; ?></span><?php echo esc_html(pa_t($title)); ?></button></li><?php } ?></ol>
 <form class="pa-form" novalidate>
 <?php foreach($steps as $i=>$title){ ?><section class="pa-step" data-panel="<?php echo $i; ?>"<?php echo $i?' hidden':''; ?>><header><p class="pa-eyebrow"><?php echo esc_html(pa_t('STEP '.($i+1).' OF 5')); ?></p><h3 tabindex="-1"><?php echo esc_html(pa_t($title)); ?></h3></header>
 <?php if($i===2&&$kind==='application'){?><p>You only need to complete the credit fields if you want to request credit. All credit requests are subject to review.</p><?php } ?>
 <?php if($i===3){ if(function_exists('pelham_lang')&&pelham_lang()==='es')echo '<p class="pa-help">'.esc_html(pa_t('The agreements are legal documents in English. The English version is the one you sign.')).'</p>'; ?><div class="pa-documents"></div><p class="pa-help">Read the complete agreements above. Confirm the signer identities and acceptances before adding signatures. Dates are recorded automatically when each document is signed.</p><?php } ?>
 <div class="pa-fields"><?php foreach($schema as $f){if(!in_array($f['group'],$groups[$i],true))continue;$key=$f['key'];$type=$f['type'];$credit=($f['condition']??'')==='credit'; ?>
 <div class="pa-field<?php echo $type==='checkbox'?' pa-wide':''; ?>"<?php if($credit)echo ' data-credit'; ?>><label for="pa-<?php echo esc_attr($key); ?>"><?php if($type!=='checkbox')echo esc_html(pa_t($f['label'])).($f['required']?' <span aria-hidden="true">*</span>':''); ?>
 <?php if($type==='select'){?><select name="<?php echo esc_attr($key); ?>" id="pa-<?php echo esc_attr($key); ?>"<?php echo $f['required']?' required':''; ?>><option value="">Select an option</option><?php foreach($f['options'] as $option)echo '<option value="'.esc_attr($option).'">'.esc_html(pa_t($option)).'</option>'; ?></select><?php }
 elseif($type==='textarea'){?><textarea name="<?php echo esc_attr($key); ?>" id="pa-<?php echo esc_attr($key); ?>" rows="4" maxlength="5000"<?php echo $f['required']?' required':''; ?>></textarea><?php }
 else{?><input type="<?php echo esc_attr(in_array($key,['tax_id','bank_account'],true)?'password':$type); ?>" name="<?php echo esc_attr($key); ?>" id="pa-<?php echo esc_attr($key); ?>"<?php echo $type==='checkbox'?' value="1"':' maxlength="250"'; ?><?php echo $type==='number'?' min="0" step="any"':''; ?><?php echo $type==='date'?' max="'.esc_attr(gmdate('Y-m-d')).'"':''; ?><?php echo $f['required']?' required':''; ?><?php echo $key==='email'?' readonly':''; ?> autocomplete="<?php echo esc_attr($key==='contact_name'?'name':($key==='email'?'email':($key==='phone'?'tel':($key==='company'?'organization':'off')))); ?>"><?php if($type==='checkbox')echo '<span>'.esc_html(pa_t($f['label'])).($f['required']?' *':'').'</span>'; ?><?php } ?></label><small class="pa-field-error" id="pa-<?php echo esc_attr($key); ?>-error"></small></div>
 <?php } ?></div>
 <?php if($i===2&&$kind==='claim'){ ?><div class="pa-attachments"><h4>Supporting evidence</h4><p>PDF, JPG, PNG or WebP. Maximum 2 MB per file. Combine additional photos into a PDF if needed.</p><?php foreach(['invoice'=>'Cost invoice supporting the value of the lost or damaged goods *','repairs'=>'Repair / replacement estimate or invoice (if available)','photos'=>'Available photographs'] as $slot=>$label){?><label><?php echo esc_html(pa_t($label)); ?><input type="file" data-attachment="<?php echo $slot; ?>" accept=".pdf,.jpg,.jpeg,.png,.webp"></label><div data-file-state="<?php echo $slot; ?>"></div><?php } ?></div><?php } ?>
 <?php if($i===3){?><div class="pa-signatures"></div><?php } ?>
 <?php if($i===4){?><p>Review your information and signatures. Editing your answers will require you to sign again so your signatures match the final information.</p><div class="pa-review"></div><p class="pa-help">Submitting this request does not automatically approve credit, settle a claim or create access to Supply Vision. Our team will review it and contact you.</p><?php } ?>
 </section><?php } ?>
 <div class="pa-actions"><button class="pa-back" type="button">← Back</button><button class="pa-next button" type="button">Continue <span aria-hidden="true">→</span></button><button class="pa-submit button" type="submit" hidden>Send for review <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path d="M5 19 19 5M6 5h13v13" fill="none" stroke="currentColor" stroke-width="1.7"/></svg></button></div>
 </form></div><div class="pa-complete" hidden></div>
 <footer class="pa-form-footer"><p>Need a hand? <a href="<?php echo esc_url(pa_link('contact')); ?>">Contact Pelham</a>. <?php if($kind==='application'){?><a href="<?php echo esc_url(pa_link('claims')); ?>">Report a shipment claim</a>.<?php } ?></p><p class="pa-help">Verified drafts and signed submissions are stored privately for review by authorized Pelham staff. <a href="<?php echo esc_url(pa_link('privacy-notice')); ?>">Privacy notice</a>.</p></footer>
 <?php if(function_exists('pelham_lang')&&pelham_lang()==='es'){$strings=json_decode(file_get_contents(PA_DIR.'/inc/i18n-strings.json'),true)?:[];foreach($schema as $f){$strings[]=$f['label'];foreach($f['options']??[] as $option)$strings[]=$option;}$map=[];foreach(array_unique($strings) as $text)$map[$text]=pelham_t($text); ?><script type="application/json" class="pa-i18n"><?php echo wp_json_encode($map,JSON_HEX_TAG|JSON_HEX_AMP|JSON_UNESCAPED_UNICODE); ?></script><?php } ?>
 <script type="application/json" class="pa-schema"><?php echo wp_json_encode($schema,JSON_HEX_TAG|JSON_HEX_AMP); ?></script>
</section>
<?php $html=ob_get_clean();
 // Spanish pages: static text of the form in Spanish (same dictionary as the site).
 return function_exists('pelham_translate_html')?pelham_translate_html($html):$html; }
// Describe digital onboarding without retaining the legacy temporary-upload claim.
// The Spanish privacy page holds the translated paragraphs, so those are matched too.
add_filter('the_content',function($content){
 $privacy=function_exists('pelham_is_page')?pelham_is_page('privacy-notice'):is_page('privacy-notice');
 if(is_admin()||!$privacy||!in_the_loop()||!is_main_query())return $content;
 $legacy='Your submissions are emailed to the Pelham team to answer your enquiry, prepare a freight discussion or review registration documents. Uploaded registration PDFs are kept in temporary server storage during delivery and removed after the delivery attempt. They are not added to the public Media library.';
 $records='Contact and quotation requests are emailed to the Pelham team. Digital applications and claims are saved as private records, including submitted information, signatures, supporting documents and the agreement versions accepted by the applicant.';
 $forms='Contact and quote forms collect the contact details and shipment information you submit. Customer registration collects your name, email, optional phone and message, and PDF documents you choose to attach. Required fields are marked on each form.';
 $digital='Contact and quote forms collect the contact details and shipment information you submit. Digital account applications collect contact, company, billing and reference details, relevant credit information, signatures and acceptance records. Freight claims also collect shipment information and supporting evidence. Required fields are marked on each form.';
 if(function_exists('pelham_lang')&&pelham_lang()==='es'){
  $content=str_replace([pa_t($legacy),pa_t($forms)],[pa_t($records),pa_t($digital)],$content);
 }else{
  $content=preg_replace('/<p>[^<]*Uploaded registration PDFs[^<]*<\/p>/i','<p>'.$records.'</p>',$content);
  $content=str_replace('Customer registration collects your name, email, optional phone and message, and PDF documents you choose to attach.','Digital account applications collect contact, company, billing and reference details, relevant credit information, signatures and acceptance records. Freight claims also collect shipment information and supporting evidence.',$content);
 }
 $days=(string)(get_option('pa_settings',[])['draft_days']??30);
 $content.='<section class="legal-page"><h2>'.esc_html(pa_t('Digital applications and claims')).'</h2><p>'.esc_html(pa_t('Verified drafts and submitted records are available only to authorized Pelham staff for review. They are not published in the website’s media library. Email notifications contain a summary and a link to the private record; bank details and personal identification numbers are not included in ordinary notification emails.')).'</p><p>'.esc_html(pa_t('Verification links expire after 30 minutes; a verified browser session lasts up to 24 hours.').' '.sprintf(pa_t('Unsubmitted drafts are removed after %s days without an update.'),$days).' '.pa_t('Contact Pelham about corrections or removal of submitted records. Submitted applications, signatures and internal decisions are retained according to the company’s record-retention policy.')).'</p></section>';
 return $content;
},40);
