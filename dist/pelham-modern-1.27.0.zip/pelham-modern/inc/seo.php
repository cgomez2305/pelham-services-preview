<?php
if (!defined('ABSPATH')) exit;

function pelham_locale_tag_safe(){return function_exists('pelham_locale_tag')?pelham_locale_tag():get_bloginfo('language');}
// Defer to a dedicated SEO plugin when one owns the page's metadata.
function pelham_theme_seo_enabled() {
 return apply_filters('pelham_theme_seo_enabled', !defined('WPSEO_VERSION') && !defined('RANK_MATH_VERSION') && !defined('AIOSEO_VERSION') && !defined('SEOPRESS_VERSION'));
}
add_filter('pre_get_document_title',function($title){
 if(!is_singular()||!pelham_theme_seo_enabled())return $title;
 $post=get_queried_object();$custom=get_post_meta($post->ID,'pelham_seo_title',true);
 if($custom)return wp_strip_all_tags($custom);
 $data=function_exists('pelham_keyword_data')?pelham_keyword_data($post):[];
 return $data['seo_title']??$title;
},20);
function pelham_seo_text($text) {
 $text = preg_replace('/\[[^\]]*\]/', ' ', strip_shortcodes($text));
 return trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($text)));
}
function pelham_seo_description($post) {
 $custom = pelham_seo_text(get_post_meta($post->ID, 'pelham_seo_description', true));
 if ($custom) return $custom;
 $data = function_exists('pelham_keyword_data') ? pelham_keyword_data($post) : [];
 if (!empty($data['description'])) return pelham_seo_text($data['description']);
 $defaults = [
  'home'=>'LTL pallet shipping from Los Angeles to Florida. Compare Expedited, Regular and Economy, plus full truckload and freight handling services.',
  'services'=>'Explore domestic LTL and FTL trucking from Los Angeles to Florida, cross-docking and palletizing.',
  'locations'=>'Explore Pelham facilities in Gardena, Orlando and Miami. Confirm receiving arrangements with the team.',
  'news'=>'Read Pelham Services insights on freight transportation, logistics, consolidation and transloading between California and Florida.',
  'contact'=>'Contact Pelham Services for freight transportation support. Reach our Gardena and Miami terminals or send a message to our team.',
  'quote'=>'Request an LTL or FTL quote from Los Angeles to Florida. Share your pallet count, dimensions, weight, pickup and business delivery details.'
 ];
 $excerpt = pelham_seo_text($post->post_excerpt);
 // Imported shortcode-only or boilerplate excerpts need a useful public summary.
 if (isset($defaults[$post->post_name]) && (!$excerpt || str_contains($post->post_excerpt, '[pelham_') || pelham_is_home())) return $defaults[$post->post_name];
 $text = $excerpt ?: pelham_seo_text($post->post_content);
 return $text ? wp_html_excerpt($text, 160, '…') : 'Explore '.get_the_title($post).' at '.get_bloginfo('name').'.';
}
function pelham_postal_address($raw) {
 $lines = preg_split('/\r?\n/', trim($raw));
 if (count($lines) > 1 && preg_match('/^(.+?),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$/', trim(end($lines)), $match)) {
  return ['@type'=>'PostalAddress', 'streetAddress'=>implode(', ', array_slice($lines,0,-1)), 'addressLocality'=>$match[1], 'addressRegion'=>$match[2], 'postalCode'=>$match[3], 'addressCountry'=>'US'];
 }
 return $raw;
}
/** Phone in E.164 (+13232014995) for schema; '' when it is not a 10-digit US number. */
function pelham_schema_phone($phone){
 $digits=preg_replace('/\D/','',(string)$phone);
 if(strlen($digits)===11&&$digits[0]==='1')$digits=substr($digits,1);
 return strlen($digits)===10?'+1'.$digits:'';
}
/**
 * Verified Google Business Profile per facility (same name, address and phone as the site).
 * Miami and Orlando stay out until the client confirms their NAP (docs/SEO-LOCAL-AUDIT-PLAN-2026-11.md).
 */
function pelham_terminal_profiles(){
 return apply_filters('pelham_terminal_profiles',['gardena-ca'=>'https://www.google.com/maps?cid=10431901153798144411']);
}
/** Area each facility serves on the Los Angeles → Florida lane (from the published offer). */
function pelham_terminal_area($route){
 return ['gardena-ca'=>[['@type'=>'City','name'=>'Los Angeles'],['@type'=>'State','name'=>'California']],'miami-fl'=>[['@type'=>'City','name'=>'Miami'],['@type'=>'Place','name'=>'South Florida']],'orlando-fl'=>[['@type'=>'City','name'=>'Orlando'],['@type'=>'Place','name'=>'Central Florida']]][$route]??[['@type'=>'State','name'=>'Florida']];
}
/** A facility identity is shared by directory, company and facility pages, in both languages. */
function pelham_terminal_entity($post, $organization_id) {
 $address=trim((string)get_post_meta($post->ID,'pelham_address',true));
 if(!$address)return null;
 // One entity per facility: the Spanish page describes the same place as the English one.
 $canonical=function_exists('pelham_translation')?(pelham_translation($post,'en')?:$post):$post;
 $url=get_permalink($canonical);$route=function_exists('pelham_route_slug')?pelham_route_slug($post):$post->post_name;
 $entity=['@type'=>'LocalBusiness','@id'=>$url.'#terminal','name'=>get_the_title($canonical),'url'=>$url,'address'=>pelham_postal_address($address),'parentOrganization'=>['@id'=>$organization_id]];
 $phone=trim((string)get_post_meta($post->ID,'pelham_phone',true));
 if($phone)$entity['telephone']=pelham_schema_phone($phone)?:$phone;
 $profiles=pelham_terminal_profiles();
 $entity['hasMap']=$profiles[$route]??'https://www.google.com/maps/search/?api=1&query='.rawurlencode(preg_replace('/\s*\R\s*/',', ',$address));
 if(isset($profiles[$route]))$entity['sameAs']=[$profiles[$route]];
 $image=get_the_post_thumbnail_url($canonical,'large');
 if(!$image&&function_exists('pelham_photo_data')){$photo=pelham_photo_data('pelham-services');$image=$photo['url']??'';}
 if($image)$entity['image']=$image;
 $entity['areaServed']=pelham_terminal_area($route);
 $entity['knowsAbout']=['LTL freight shipping','Full truckload shipping','Cross-docking','Palletizing','Los Angeles to Florida freight'];
 return $entity;
}
// Archive routes are discoverable through WordPress sitemaps too. They need
// their own metadata; singular rel_canonical() does not cover these routes.
add_action('wp_head',function(){
 if(!is_archive()||!pelham_theme_seo_enabled())return;
 $url=remove_query_arg(['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid'],get_pagenum_link(max(1,(int)get_query_var('paged')),false));
 $title=wp_get_document_title();
 $archive=wp_strip_all_tags(get_the_archive_title());
 $description=pelham_lang()==='es'?'Artículos de '.$archive.' de '.get_bloginfo('name').': planificación de carga, transporte y noticias de la empresa.':'Browse '.$archive.' articles from '.get_bloginfo('name').': freight planning, transport and company updates.';
 if(get_query_var('paged')>1)$description.=' '.pelham_t('Page').' '.(int)get_query_var('paged').'.';
 echo '<link rel="canonical" href="'.esc_url($url).'">'."\n";
 echo '<meta name="description" content="'.esc_attr($description).'">'."\n";
 $logo_id=get_theme_mod('custom_logo');
 $image=($logo_id?wp_get_attachment_image_url($logo_id,'full'):false)?:get_template_directory_uri().'/assets/pelham-logo.png';
 foreach(['og:type'=>'website','og:title'=>$title,'og:description'=>$description,'og:url'=>$url,'og:site_name'=>get_bloginfo('name'),'og:locale'=>str_replace('-','_',pelham_locale_tag_safe()),'og:image'=>$image,'og:image:alt'=>get_bloginfo('name')] as $key=>$value)echo '<meta property="'.esc_attr($key).'" content="'.esc_attr($value).'">'."\n";
 foreach(['twitter:card'=>'summary','twitter:title'=>$title,'twitter:description'=>$description,'twitter:image'=>$image] as $key=>$value)echo '<meta name="'.esc_attr($key).'" content="'.esc_attr($value).'">'."\n";
 echo '<script type="application/ld+json">'.wp_json_encode(['@context'=>'https://schema.org','@type'=>'CollectionPage','@id'=>$url.'#webpage','url'=>$url,'name'=>$title,'description'=>$description,'inLanguage'=>pelham_locale_tag_safe()],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>'."\n";
},20);
add_action('wp_head',function(){
 if (!is_singular() || !pelham_theme_seo_enabled()) return;
 $post = get_queried_object();
 $url = get_permalink($post);
 $title = wp_get_document_title();
 $description = pelham_seo_description($post);
 $logo_id = get_theme_mod('custom_logo');
 $logo = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : get_template_directory_uri().'/assets/pelham-logo.png';
 $photo_data=function_exists('pelham_keyword_data')?pelham_keyword_data($post):[];
 $stock=function_exists('pelham_photo_data')?pelham_photo_data($photo_data['photo']??'truck'):[];
 // A 156px logo is below the size social networks and Article rich results
 // accept; pages without their own photo share the homepage fleet photo.
 if(empty($stock['url'])&&function_exists('pelham_photo_data'))$stock=pelham_photo_data('pelham-services');
 $image = get_the_post_thumbnail_url($post, 'large') ?: ($stock['url']??$logo);
 $image_alt = has_post_thumbnail($post) ? get_post_meta(get_post_thumbnail_id($post),'_wp_attachment_image_alt',true) : ($stock['alt']??get_bloginfo('name'));
 echo '<meta name="description" content="'.esc_attr($description).'">'."\n";
 $meta = ['og:type'=>get_post_type($post)==='post'?'article':'website', 'og:title'=>$title, 'og:description'=>$description, 'og:url'=>$url, 'og:site_name'=>get_bloginfo('name'), 'og:locale'=>str_replace('-', '_', pelham_locale_tag_safe()), 'og:image'=>$image, 'og:image:alt'=>$image_alt];
 foreach ($meta as $property=>$value) echo '<meta property="'.esc_attr($property).'" content="'.esc_attr($value).'">'."\n";
 // The other language version of this page, for social previews.
 if (function_exists('pelham_alternates') && count(array_filter(pelham_alternates()))===2) echo '<meta property="og:locale:alternate" content="'.(pelham_lang()==='es'?'en_US':'es_US').'">'."\n";
 foreach (['twitter:card'=>'summary_large_image','twitter:title'=>$title,'twitter:description'=>$description,'twitter:image'=>$image,'twitter:image:alt'=>$image_alt] as $name=>$value) echo '<meta name="'.esc_attr($name).'" content="'.esc_attr($value).'">'."\n";
 // The brand is «Pelham Services» (site title is the short «Pelham»); the legal entity is Pelham Services CA Corp.
 $brand_logo=function_exists('pelham_logo_url')&&file_exists(get_template_directory().'/assets/pelham-logo.png')?pelham_logo_url('pelham-logo.png'):$logo;
 $org = ['@type'=>'Organization','@id'=>home_url('/').'#organization','name'=>'Pelham Services','legalName'=>'Pelham Services CA Corp','alternateName'=>get_bloginfo('name'),'url'=>home_url('/'),'logo'=>$brand_logo];
 $main_phone=pelham_schema_phone(function_exists('pelham_detail')?pelham_detail('ca_phone','323-201-4995'):'323-201-4995');
 if($main_phone){$org['telephone']=$main_phone;$org['contactPoint']=[['@type'=>'ContactPoint','contactType'=>'sales','telephone'=>$main_phone,'areaServed'=>'US','availableLanguage'=>['English','Spanish']]];}
 if (pelham_detail('email')) $org['email'] = pelham_detail('email');
 $defaults = function_exists('pelham_defaults') ? pelham_defaults() : [];
 $social = array_values(array_filter([pelham_detail('facebook',$defaults['facebook']??''),pelham_detail('linkedin',$defaults['linkedin']??'')],fn($url)=>!empty($url)&&in_array(wp_parse_url($url,PHP_URL_SCHEME),['https','http'],true)&&wp_parse_url($url,PHP_URL_HOST)));
 if ($social) $org['sameAs'] = $social;
 $website = ['@type'=>'WebSite','@id'=>home_url('/').'#website','url'=>home_url('/'),'name'=>'Pelham Services','alternateName'=>get_bloginfo('name'),'publisher'=>['@id'=>$org['@id']],'inLanguage'=>get_option('pelham_es_home')?['en-US','es-US']:get_bloginfo('language')];
 $page = ['@type'=>'WebPage','@id'=>$url.'#webpage','url'=>$url,'name'=>$title,'description'=>$description,'publisher'=>['@id'=>$org['@id']]];
 $page['isPartOf'] = ['@id'=>$website['@id']];
 $page['inLanguage'] = pelham_locale_tag_safe();
 $page['breadcrumb'] = ['@id'=>$url.'#breadcrumb'];
 $breadcrumbs = [];
 foreach (pelham_breadcrumb_trail($post) ?: [[pelham_t('Home'),pelham_home_link()]] as $i=>[$name,$item]) $breadcrumbs[] = ['@type'=>'ListItem','position'=>$i+1,'name'=>$name,'item'=>$item ?: $url];
 $type = get_post_type($post);
 $graph = [$org,$website,$page,['@type'=>'BreadcrumbList','@id'=>$url.'#breadcrumb','itemListElement'=>$breadcrumbs]];
 if ($type==='pelham_service') {
  $service=['@type'=>'Service','@id'=>$url.'#service','name'=>get_the_title($post),'description'=>$description,'url'=>$url,'provider'=>['@id'=>$org['@id']],'audience'=>['@type'=>'BusinessAudience','audienceType'=>pelham_t('Suppliers, distributors, manufacturers and freight forwarders')]];
  if(pelham_route_slug($post)==='freight-consolidation'&&function_exists('pelham_ltl_levels')){
   $service['serviceType']=pelham_t('Domestic less-than-truckload pallet shipping from Los Angeles to Florida');
   $service['areaServed']=[['@type'=>'City','name'=>'Los Angeles'],['@type'=>'State','name'=>'Florida']];$offers=[];
   foreach(pelham_ltl_levels() as $key=>$level)$offers[]=['@type'=>'Offer','url'=>add_query_arg(['service'=>'freight-consolidation','ltl_level'=>$key],pelham_link('quote')),'itemOffered'=>['@type'=>'Service','name'=>'LTL '.$level[0],'serviceType'=>pelham_t('Domestic LTL trucking from Los Angeles'),'areaServed'=>$key==='expedited'?['@type'=>'Place','name'=>pelham_t('South Florida: Homestead to West Palm Beach')]:['@type'=>'State','name'=>'Florida'],'description'=>$level[1].' '.pelham_t('calendar days from pickup in Los Angeles, estimated and not guaranteed.').' '.pelham_t($level[2])]];
   $service['hasOfferCatalog']=['@type'=>'OfferCatalog','name'=>pelham_t('Pelham LTL transit levels'),'itemListElement'=>$offers];
  }
  $graph[2]['mainEntity']=['@id'=>$service['@id']];
  $graph[]=$service;
 }
 if ($type==='pelham_terminal') {
  $local=pelham_terminal_entity($post,$org['@id']);
  if($local){$graph[]=$local;$graph[2]['mainEntity']=['@id'=>$local['@id']];}
 }
 // Match entities already shown in the public facility directory and footer.
 if(pelham_is_home()||pelham_is_page(['about','locations'])){
  $branches=[];
  foreach(get_posts(['post_type'=>'pelham_terminal','post_status'=>'publish','numberposts'=>-1]) as $terminal){
   $local=pelham_terminal_entity($terminal,$org['@id']);
   if($local){$branches[]=['@id'=>$local['@id']];$graph[]=$local;}
  }
  if($branches)$graph[0]['subOrganization']=$branches;
  if(pelham_is_home()||pelham_is_page('about'))$graph[2]['mainEntity']=['@id'=>$org['@id']];
 }
 if ($type==='post') {
  $article = ['@type'=>'Article','@id'=>$url.'#article','headline'=>get_the_title($post),'description'=>$description,'datePublished'=>get_the_date(DATE_W3C,$post),'dateModified'=>get_the_modified_date(DATE_W3C,$post),'publisher'=>['@id'=>$org['@id']],'mainEntityOfPage'=>['@id'=>$page['@id']]];
  $article['inLanguage']=pelham_locale_tag_safe();
  $graph[2]['mainEntity']=['@id'=>$article['@id']];
  $article['author']=['@id'=>$org['@id']];
  if ($image!==$logo) $article['image']=$image;
  $graph[]=$article;
 }
 echo '<script type="application/ld+json">'.wp_json_encode(['@context'=>'https://schema.org','@graph'=>$graph],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>'."\n";
},20);
