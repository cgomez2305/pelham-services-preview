(() => {
	document.querySelectorAll('.pa-doc-navigation a').forEach(link => link.addEventListener('click', () => {
		const card = document.querySelector(link.hash);
		if (card) {
			card.open = true;
			card.querySelector('summary')?.focus();
		}
	}));
})();
(() => {
	const box = document.querySelector('.pa-admin-sign');
	if (!box) return;
	const canvas = box.querySelector('canvas'),
		ctx = canvas.getContext('2d'),
		field = box.querySelector('[name=representative_signature]');
	let drawing = false;

	function reset() {
		ctx.fillStyle = '#fff';
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.strokeStyle = '#143b2a';
		ctx.lineWidth = 3;
		ctx.lineCap = 'round';
		field.value = '';
	}
	reset();

	function point(e) {
		const r = canvas.getBoundingClientRect();
		return [(e.clientX - r.left) * canvas.width / r.width, (e.clientY - r.top) * canvas.height / r.height]
	}
	canvas.onpointerdown = e => {
		drawing = true;
		canvas.setPointerCapture(e.pointerId);
		ctx.beginPath();
		ctx.moveTo(...point(e));
	};
	canvas.onpointermove = e => {
		if (drawing) {
			ctx.lineTo(...point(e));
			ctx.stroke();
			field.value = canvas.toDataURL('image/jpeg', .9)
		}
	};
	canvas.onpointerup = canvas.onpointercancel = () => drawing = false;
	box.querySelector('.pa-admin-clear').onclick = reset;
	box.querySelector('.pa-admin-upload').onchange = async e => {
		const f = e.target.files[0];
		if (!f) return;
		if (f.size > 1000000 || !['image/png', 'image/jpeg', 'image/webp'].includes(f.type)) {
			alert('Use a JPG, PNG or WebP image up to 1 MB.');
			return;
		}
		try {
			const im = await createImageBitmap(f);
			if (im.width > 4096 || im.height > 4096) {
				im.close();
				throw Error('Image too large.')
			}
			reset();
			const r = Math.min(canvas.width / im.width, canvas.height / im.height);
			ctx.drawImage(im, (canvas.width - im.width * r) / 2, (canvas.height - im.height * r) / 2, im.width * r, im.height * r);
			im.close();
			field.value = canvas.toDataURL('image/jpeg', .9)
		} catch {
			alert('Unable to read this signature image.')
		}
	}
})();
